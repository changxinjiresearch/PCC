# Stage A test execution

Full pytest output is saved unedited in `FULL_PYTEST_OUTPUT.txt`; local static/synthetic tests completed with exit code 0. GPU kernel QC completed 115/115 P0, all finite/in-range, 0 access violations, 0 failures. No target, method or performance computation was executed.
