No unresolved failures. All 115 cases completed on attempt 1; first-attempt logs are retained.
