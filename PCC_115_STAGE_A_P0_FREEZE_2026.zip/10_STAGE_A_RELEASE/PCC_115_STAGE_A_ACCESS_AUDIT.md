Access audit PASS: 805 permitted current/checkpoint reads, 0 forbidden reads, 0 future files, 0 target constructions.
