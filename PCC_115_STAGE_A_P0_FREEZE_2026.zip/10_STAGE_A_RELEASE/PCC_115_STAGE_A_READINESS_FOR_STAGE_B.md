Stage A is frozen and may be read by a separately authorized Stage B. This kernel did not start Stage B.
