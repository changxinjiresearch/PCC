# PCC Scientific Reports V2.1 release report

- Title: Target-conditioned refinement of future-blind longitudinal glioma segmentation-change maps across independent cohorts
- Abstract: 152 words
- Introduction / Results / Discussion: 753 / 1378 / 1253 words
- Scientific Reports main text: 3384 words
- Methods: 1356 words
- References: 16
- Display items: 5 figures + 3 tables
- Frozen internal rows / trajectories: 904 / 1130
- Frozen RHUH rows / trajectories: 273 / 390
- Numeric mismatches: 0
- Citation failures: 0
- Scientific experiments rerun: 0
- LUMIERE started: false
- Package SHA-256: `2e1562b9c11cd3202e9b961fb6df4bb8ac57625cda5ba06f519144f8702b5184`
- Gate: PASS_FOR_FINAL_INDEPENDENT_ROUND3_REVIEW
